<div class="banner-area">
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row height align-items-center justify-content-center">
			<div class="col-lg-9">
				<div class="banner-content text-center">
					<h4 class="text-uppercase"><?= $description; ?></h4>
					<h1><?= $title; ?></h1>
					<?php if ($user) : ?>
						<div class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Selamat Datang <?= $user['name']; ?></span></div>
					<?php else : ?>
						<a href="<?= base_url('Auth'); ?>" class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Get Started</span><span class="lnr lnr-arrow-right"></span></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<div class="main-wrapper">
	<!-- Start Align Area -->
	<div class="white-bg">
		<div class="container">
			<div class="section-top-border">
				<div class="text-center">
					<h3 class="judul">ABOUT</h3>
					<p class="mt-2">Informasi Tentang CV Azharku Media</p>
					<hr>
				</div>
				<div class="row justify-content-center p-5 text-justify">
					<div class="col-md-6">
						<div class="text-center">
							<img class="w-50" src="<?= base_url('assets/images/profile/azhar.png') ?>" alt="">
							<h4 class="namalogo">CV AZHARKU-MEDIA</h4>
						</div>
					</div>
					<div class="col-md-6">
						<p class="teks">
							Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odio aperiam porro eligendi? Quis eaque et deleniti. Amet accusantium, reprehenderit sunt rem deserunt enim voluptates quam similique blanditiis dolores magni! Laboriosam.
						</p>
					</div>
				</div>
			</div>
			<div class="section-top-border">
				<div class="text-center">
					<h3 class="judul">PORTFOLIO</h3>
					<p class="mt-2">Gambar Porfolio Dari CV Azharku Media</p>
					<hr>
				</div>
				<div class="row gallery-item">
					<div class="col-md-4 mb-4">
						<div class="card text-center border-primary">
							<div class="card-header">
								Featured
							</div>
							<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g3.jpg'); ?>);">
								<h5 class="card-title">Special title treatment</h5>
								<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
								<a href="#" class="btn btn-primary">Go somewhere</a>
							</div>
							<div class="card-footer text-muted">
								2 days ago
							</div>
						</div>
					</div>
					<div class="col-md-4 mb-4">
						<div class="card text-center border-primary">
							<div class="card-header">
								Featured
							</div>
							<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g2.jpg'); ?>);">
								<h5 class="card-title">Special title treatment</h5>
								<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
								<a href="#" class="btn btn-primary">Go somewhere</a>
							</div>
							<div class="card-footer text-muted">
								2 days ago
							</div>
						</div>
					</div>
					<div class="col-md-4 mb-4">
						<div class="card text-center border-primary">
							<div class="card-header">
								Featured
							</div>
							<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g1.jpg'); ?>);">
								<h5 class="card-title">Special title treatment</h5>
								<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
								<a href="#" class="btn btn-primary">Go somewhere</a>
							</div>
							<div class="card-footer text-muted">
								2 days ago
							</div>
						</div>
					</div>
					<div class="col-md-4 mb-4">
						<div class="card text-center border-primary">
							<div class="card-header">
								Featured
							</div>
							<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g4.jpg'); ?>);">
								<h5 class="card-title">Special title treatment</h5>
								<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
								<a href="#" class="btn btn-primary">Go somewhere</a>
							</div>
							<div class="card-footer text-muted">
								2 days ago
							</div>
						</div>
					</div>
					<div class="col-md-4 mb-4">
						<div class="card text-center border-primary">
							<div class="card-header">
								Featured
							</div>
							<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g5.jpg'); ?>);">
								<h5 class="card-title">Special title treatment</h5>
								<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
								<a href="#" class="btn btn-primary">Go somewhere</a>
							</div>
							<div class="card-footer text-muted">
								2 days ago
							</div>
						</div>
					</div>
					<div class="col-md-4 mb-4">
						<div class="card text-center border-primary">
							<div class="card-header">
								Featured
							</div>
							<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g6.jpg'); ?>);">
								<h5 class="card-title">Special title treatment</h5>
								<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
								<a href="#" class="btn btn-primary">Go somewhere</a>
							</div>
							<div class="card-footer text-muted">
								2 days ago
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>