<div class="banner-area">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row height align-items-center justify-content-center">
            <div class="col-lg-12">
                <div class="banner-content text-center">
                    <h4 class="text-uppercase mb-3"><?= $title; ?></h4>
                    <div class="container">
                        <?= $this->session->flashdata('message'); ?>
                        <?php echo form_open_multipart('Profile/update'); ?>
                        <input type="hidden" name="id" value="<?= $user['id']; ?>">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="mt-3">
                                    <input name="name" placeholder="Enter Full Name" id="nama_pelanggan" class="common-input mt-20" type="text" value="<?= $user['name']; ?>" />
                                    <?= form_error('name', '<small class="text-danger float-left">', '</small>'); ?>
                                </div>
                                <div class="mt-3">
                                    <input name="no_hp" placeholder="Enter No Handphone" class="common-input mt-20" type="text" value="<?= $user['no_hp']; ?>">
                                    <?= form_error('no_hp', '<small class="text-danger float-left">', '</small>'); ?>
                                </div>
                                <div class="mt-3">
                                    <textarea class="common-textarea" placeholder="Enter To Address" name="alamat"><?= $user['alamat'] ?></textarea>
                                    <?= form_error('alamat', '<small class="text-danger float-left">', '</small>'); ?>
                                </div>

                            </div>
                            <div class="col-lg-5">
                                <div class="mt-3">
                                    <img src="<?= base_url('assets/images/profile/') . $user['images']; ?>" class="img-thumbnail w-50" style="border-radius:50%;" />
                                </div>
                                <div class="col-md-8 custom-file mt-3">
                                    <input name="images" type="file" class="common-input custom-file-input" id="customFile">
                                    <label class="common-input custom-file-label" for="customFile">Choose file</label>
                                </div>
                            </div>
                            <div class="col-lg-8 d-flex justify-content-end">
                                <button type="submit" class="primary-btn d-inline-flex align-items-center mt-20"><span class="text-white mr-10">Update</span><span class="text-white lnr lnr-arrow-right"></span></button>
                                <br>
                            </div>
                        </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="main-wrapper">
</div>

<script src="<?= base_url('assets/web/js/vendor/jquery-2.2.4.min.js'); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="<?= base_url('assets/web/js/vendor/bootstrap.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.ajaxchimp.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/owl.carousel.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.nice-select.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/parallax.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.magnific-popup.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/main.js'); ?>"></script>
<script>
	$('.custom-file-input').on('change',function(){
		let fileName = $(this).val().split('\\').pop();
		$(this).next('.custom-file-label').addClass("selected").html(fileName);
	});
</script>
</body>

</html>