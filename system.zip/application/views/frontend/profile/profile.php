<div class="banner-area">
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row align-items-center justify-content-center" style="height:20rem;">
			<div class="col-lg-9">
				<div class="banner-content text-center">
					<h4 class="text-uppercase"><?= $title; ?></h4>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<div class="main-wrapper">
	<div class="white-bg">
		<div class="container profil">
			<div class="row justify-content-center p-5">
				<div class="col-md-5 text-center">
					<img src="<?= base_url('assets/images/profile/') . $user['images']; ?>" class="img-thumbnail w-50" style="border-radius:50%;" alt="<?= $user['name']; ?>" data-toggle="tooltip" tabindex="0" title="<?= $user['name']; ?>">
					<h4 style="font-weight:bold; font-family:Franklin Gothic Medium; margin-top:0.5rem;"><?= $user['name']; ?></h4>
					<h4 class="text-muted" style="font-family:'Times New Roman', Times, serif"><?= $user['email_pelanggan']; ?></h4>
				</div>
				<div class="col-md-7">
					<div class="d-inline">
						<h3 class="about-title mb-10">Nama</h3>
						<p><?= $user['name']; ?></p>
						<h3 class="about-title mb-10 mt-3">No Handphone</h3>
						<p><?= $user['no_hp']; ?></p>
						<h3 class="about-title mb-10 mt-3">Alamat</h3>
						<p><?= $user['alamat']; ?></p>
						<div class="p-5 float-right" style="font-size:1.3rem; padding-top:5rem;">
							<a href="<?= base_url('Profile/update/').$user['id']; ?>" class="primary-btn hover d-inline-flex align-items-center"><span class="mr-10">Update Profile</span><span class="lnr lnr-arrow-right"></span></a>
							<!-- <a href="<?= base_url('Profile/update/') . $user['id']; ?>" class="badge badge-primary"><i class="fa fa-edit text-white"></i> Update Profile</!-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>