<div class="banner-area">
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div id="auth" data-flashdata="<?= $this->session->flashdata('auth'); ?>"></div>
		<div class="row height align-items-center justify-content-center">
			<div class="col-lg-7">
				<div class="banner-content text-center">
					<h4 class="text-uppercase">Selamat Datang Di Website Azharku Media</h4>
					<h1>Welcome</h1>
					<?php if ($user) : ?>
						<div  class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Selamat Datang <?= $user['name'];?></span></div>
					<?php else : ?>
						<a href="<?= base_url('Auth'); ?>" class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Get Started</span><span class="lnr lnr-arrow-right"></span></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<div class="main-wrapper">
	<!-- Start Feature Area -->
	<section class="featured-area pt-100 pb-100">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-6">
					<div class="feature-left">
						<h2>
							Reasons To <br>
							<span>Choose</span> Notebook
						</h2>
						<p>
							Here, I focus on a range of items and features that we use in life without giving them a second thought. such as Coca Cola. Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.
						</p>
						<button class="primary-btn hover d-inline-flex align-items-center"><span class="mr-10">Get Started</span><span class="lnr lnr-arrow-right"></span></button>
					</div>
				</div>
				<div class="col-md-6">
					<div class="feature-right active-feature-carousel">
						<div class="single-slider item">
							<img src="<?= base_url('assets/web/img/slider.jpg'); ?>" alt="">
						</div>
						<div class="single-slider item">
							<img src="<?= base_url('assets/web/img/slider.jpg'); ?>" alt="">
						</div>
						<div class="single-slider item">
							<img src="<?= base_url('assets/web/img/slider.jpg'); ?>" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Feature Area -->
	<!-- Start parallux Area -->
	<section class="parallux-area pt-100 pb-100 relative" data-parallax="scroll" data-image-src="<?= base_url('assets/web/img/parallux-bg.jpg'); ?>">
		<div class="overlay overlay-bg"></div>
		<div class="container">
			<div class="row justify-content-end">
				<div class="col-lg-5 col-md-6 col-sm-12">
					<h2>
						Reasons To <br>
						<span>Choose</span> Notebook
					</h2>
					<p>
						Here, I focus on a range of items and features that we use in life without giving them a second thought. such as Coca Cola. Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.
					</p>
					<a href="#" class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Get Started</span><span class="lnr lnr-arrow-right"></span></a>
				</div>
			</div>
		</div>
	</section>
	<!-- End parallux Area -->
	<!-- Start service Area -->
	<section class="service-area">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="single-service" style="background: url(<?= base_url('assets/web/img/s1.jpg'); ?>);">
						<div class="overlay overlay-content">
							<h4 class="text-uppercase">Becoming A Dvd Repair Expert Online</h4>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
							</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="single-service" style="background: url(<?= base_url('assets/web/img/s2.jpg'); ?>);">
						<div class="overlay overlay-content">
							<h4 class="text-uppercase">Becoming A Dvd Repair Expert Online</h4>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
							</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="single-service" style="background: url(<?= base_url('assets/web/img/s3.jpg'); ?>);">
						<div class="overlay overlay-content">
							<h4 class="text-uppercase">Becoming A Dvd Repair Expert Online</h4>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
							</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="single-service" style="background: url(<?= base_url('assets/web/img/s4.jpg'); ?>);">
						<div class="overlay overlay-content">
							<h4 class="text-uppercase">Becoming A Dvd Repair Expert Online</h4>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>