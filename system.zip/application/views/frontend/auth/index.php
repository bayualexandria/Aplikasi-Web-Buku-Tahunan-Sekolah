<div class="banner-area">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row height align-items-center justify-content-center">
            <div class="col-lg-7">
                <div class="banner-content text-center">
                    <h4 class="text-uppercase mb-3"><?= $title; ?></h4>
                    <div class="container">
                        <h6 class="text-center text-white mt-5">Belum punya akun. Klik disini untuk membuat akun <a href="<?= base_url('Auth/register'); ?>">Registrasi</a></h6>
                        <?= $this->session->flashdata('message'); ?>

                        <form action="<?= base_url('Auth'); ?>" method="post" class="contact-form">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <input name="email" placeholder="Enter email address" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'" class="common-input mt-20" type="email">
                                    <?= form_error('email', '<small class="text-danger float-left">', '</small>'); ?>
                                </div>

                                <div class="col-lg-8">
                                    <input name="password" placeholder="Enter your password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your password'" class="common-input mt-20" type="password">
                                    <?= form_error('password', '<small class="float-left text-danger">', '</small>'); ?>
                                </div>

                                <div class="col-lg-8 d-flex justify-content-end">
                                <h6 class="text-white d-inline text-left mt-2" style="margin-right:10rem;"><a href="<?= base_url('Auth/forgot');?>">Lupa Password ?</a></h6>
                                    <button type="submit" class="primary-btn d-inline-flex align-items-center mt-20"><span class="text-white mr-10">Login</span><span class="text-white lnr lnr-arrow-right"></span></button>
                                    <br>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="main-wrapper">
</div>

<script src="<?= base_url('assets/web/js/vendor/jquery-2.2.4.min.js'); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="<?= base_url('assets/web/js/vendor/bootstrap.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.ajaxchimp.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/owl.carousel.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.nice-select.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/parallax.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.magnific-popup.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/main.js'); ?>"></script>
</body>

</html>