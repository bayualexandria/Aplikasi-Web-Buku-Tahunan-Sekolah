<div class="banner-area">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row height align-items-center justify-content-center">
            <div class="col-lg-12">
                <div class="banner-content text-center">
                    <h4 class="text-uppercase mb-3"><?= $title; ?></h4>
                    <div class="container">
                        <h6 class="text-center text-white mt-5">Klik disini untuk <a href="<?= base_url('Auth'); ?>">Login</a></h6>
                        <?= $this->session->flashdata('message'); ?>

                        <form action="<?= base_url('Auth/register'); ?>" method="post" class="contact-form">
                            <div class="row justify-content-center">
                                <div class="col-lg-5">
                                    <div class="mt-3">
                                        <input name="name" placeholder="Enter Full Name" id="nama_pelanggan" class="common-input mt-20" type="text" value="<?= set_value('name') ?>">
                                        <?= form_error('name', '<small class="text-danger float-left">', '</small>'); ?>
                                    </div>
                                    <div class="mt-3">
                                        <input name="no_hp" placeholder="Enter No Handphone" class="common-input mt-20" type="text" value="<?= set_value('no_hp') ?>">
                                        <?= form_error('no_hp', '<small class="text-danger float-left">', '</small>'); ?>
                                    </div>
                                    <div class="mt-3">
                                        <textarea class="common-textarea" placeholder="Enter To Address" name="alamat"><?= set_value('alamat') ?></textarea>
                                        <?= form_error('alamat', '<small class="text-danger float-left">', '</small>'); ?>
                                    </div>

                                </div>
                                <div class="col-lg-5">
                                    <div class="mt-3">

                                        <input name="email" placeholder="Enter Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'" class="common-input mt-20" type="email" value="<?= set_value('email') ?>">
                                        <?= form_error('email', '<small class="text-danger float-left">', '</small>'); ?>
                                    </div>
                                    <div class="mt-3">

                                        <input name="password" placeholder="Enter Your Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your password'" class="common-input mt-20" type="password">
                                        <?= form_error('password', '<small class="float-left text-danger">', '</small>'); ?>
                                    </div>
                                    <div class="mt-3">

                                        <input name="repassword" placeholder="Enter Your Re Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your re password'" class="common-input mt-20" type="password">
                                        <?= form_error('repassword', '<small class="float-left text-danger">', '</small>'); ?>
                                    </div>
                                </div>



                                <div class="col-lg-8 d-flex justify-content-end">
                                    <button type="submit" class="primary-btn d-inline-flex align-items-center mt-20"><span class="text-white mr-10">Register</span><span class="text-white lnr lnr-arrow-right"></span></button>
                                    <br>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="main-wrapper">
</div>

<script src="<?= base_url('assets/web/js/vendor/jquery-2.2.4.min.js'); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js');?>/1.11.0/umd/popper.min.js');?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="<?= base_url('assets/web/js/vendor/bootstrap.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.ajaxchimp.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/owl.carousel.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.nice-select.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/parallax.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.magnific-popup.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/main.js'); ?>"></script>
</body>

</html>