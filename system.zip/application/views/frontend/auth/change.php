<div class="banner-area">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row height align-items-center justify-content-center">
            <div class="col-lg-7">
                <div class="banner-content text-center">
                    <h4 class="text-uppercase mb-3"><?= $title; ?></h4>
                    <div class="container">
                    <h5 class="text-white bold"><?= $this->session->userdata('reset_email');?></h5>
                        <?= $this->session->flashdata('message'); ?>

                        <form action="<?= base_url('Auth/change'); ?>" method="post" class="contact-form">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <input name="password" placeholder="Enter your new password..." onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your password...'" class="common-input mt-20" type="password">
                                    <?= form_error('password', '<small class="text-danger float-left">', '</small>'); ?>
                                </div>
                                <div class="col-lg-8">
                                    <input name="repassword" placeholder="Enter your new re password..." onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your re password'" class="common-input mt-20" type="password">
                                    <?= form_error('repassword', '<small class="text-danger float-left">', '</small>'); ?>
                                </div>

                                <div class="col-lg-8 d-flex justify-content-end">
                                    <button type="submit" class="primary-btn align-items-center mt-20"><span class="text-white mr-10">Change Password</span><span class="text-white lnr lnr-arrow-right"></span></button>
                                    <br>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="main-wrapper">
</div>

<script src="<?= base_url('assets/web/js/vendor/jquery-2.2.4.min.js'); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js');?>/1.11.0/umd/popper.min.js');?>" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="<?= base_url('assets/web/js/vendor/bootstrap.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.ajaxchimp.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/owl.carousel.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.nice-select.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/parallax.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.magnific-popup.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/main.js'); ?>"></script>
</body>

</html>