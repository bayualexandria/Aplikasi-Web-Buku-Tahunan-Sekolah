<div class="banner-area">
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row height align-items-center justify-content-center">
			<div class="col-lg-9">
				<div class="banner-content text-center">
					<h4 class="text-uppercase"><?= $description; ?></h4>
					<h1><?= $title; ?></h1>
					<?php if ($user) : ?>
						<div class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Selamat Datang <?= $user['name']; ?></span></div>
					<?php else : ?>
						<a href="<?= base_url('Auth'); ?>" class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Get Started</span><span class="lnr lnr-arrow-right"></span></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<div class="main-wrapper">
	<!-- Start parallux Area -->
	<!-- <section class="parallux-area pt-100 pb-100 relative" data-parallax="scroll" data-image-src="<?= base_url('assets/web/img/parallux-bg.jpg'); ?>">
		<div class="overlay overlay-bg"></div>
		<div class="container">
			<div class="row justify-content-end">
				<div class="col-lg-5 col-md-6 col-sm-12">
					<h2>
						Reasons To <br>
						<span>Choose</span> Notebook
					</h2>
					<p>
						Here, I focus on a range of items and features that we use in life without giving them a second thought. such as Coca Cola. Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.
					</p>
					<a href="#" class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Get Started</span><span class="lnr lnr-arrow-right"></span></a>
				</div>
			</div>
		</div>
	</section> -->
	<!-- End parallux Area -->
	<!-- About Generic Start -->
	<section class="about-generic-area">
		<div class="container border-top-generic">
			<div class="text-center">
				<h3 class="judul">DAFTAR DESAIN</h3>
				<p class="mt-2">Kumpulan Desain Yang Bisa Dipilih</p>
				<hr>
			</div>
			<div class="row gallery-item">
				<div class="col-md-4 mb-4">
					<div class="card text-center">
						<div class="card-header">
							Featured
						</div>
						<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g3.jpg'); ?>);">
							<h5 class="card-title">Special title treatment</h5>
							<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
							<a href="#" class="btn btn-primary">Go somewhere</a>
						</div>
						<div class="card-footer text-muted">
							2 days ago
						</div>
					</div>
				</div>
				<div class="col-md-4 mb-4">
					<div class="card text-center">
						<div class="card-header">
							Featured
						</div>
						<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g2.jpg'); ?>);">
							<h5 class="card-title">Special title treatment</h5>
							<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
							<a href="#" class="btn btn-primary">Go somewhere</a>
						</div>
						<div class="card-footer text-muted">
							2 days ago
						</div>
					</div>
				</div>
				<div class="col-md-4 mb-4">
					<div class="card text-center">
						<div class="card-header">
							Featured
						</div>
						<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g1.jpg'); ?>);">
							<h5 class="card-title">Special title treatment</h5>
							<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
							<a href="#" class="btn btn-primary">Go somewhere</a>
						</div>
						<div class="card-footer text-muted">
							2 days ago
						</div>
					</div>
				</div>
				<div class="col-md-4 mb-4">
					<div class="card text-center">
						<div class="card-header">
							Featured
						</div>
						<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g4.jpg'); ?>);">
							<h5 class="card-title">Special title treatment</h5>
							<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
							<a href="#" class="btn btn-primary">Go somewhere</a>
						</div>
						<div class="card-footer text-muted">
							2 days ago
						</div>
					</div>
				</div>
				<div class="col-md-4 mb-4">
					<div class="card text-center">
						<div class="card-header">
							Featured
						</div>
						<div class="card-body" style="background-image:url(<?= base_url('assets/web/img/g5.jpg'); ?>);">
							<h5 class="card-title">Special title treatment</h5>
							<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
							<a href="#" class="btn btn-primary">Go somewhere</a>
						</div>
						<div class="card-footer text-muted">
							2 days ago
						</div>
					</div>
				</div>
				<div class="col-md-4 mb-4">
					<div class="card bg-dark text-white">
						<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
							<ol class="carousel-indicators">
								<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
								<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
								<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
								<li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
							</ol>
							<div class="carousel-inner">
								<div class="carousel-item active">
									<img src="<?= base_url('assets/web/img/g1.jpg'); ?>" class="d-block w-100" alt="...">
								</div>
								<div class="carousel-item">
									<img src="<?= base_url('assets/web/img/g3.jpg'); ?>" class="d-block w-100" alt="...">
								</div>
								<div class="carousel-item">
									<img src="<?= base_url('assets/web/img/g2.jpg'); ?>" class="d-block w-100" alt="...">
								</div>
								<div class="carousel-item">
									<img src="<?= base_url('assets/web/img/g3.jpg'); ?>" class="d-block w-100" alt="...">
								</div>
							</div>
							<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							</a>
							<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							</a>
						</div>
						<div class="card-img-overlay">
							<h5 class="card-title">Card title</h5>
							<p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
							<p class="card-text">Last updated 3 mins ago</p>
						</div>
					</div>
				</div>
			</div>
	</section>