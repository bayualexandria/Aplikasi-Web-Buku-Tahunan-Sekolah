<div class="banner-area">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row height align-items-center justify-content-center">
            <div class="col-lg-9">
                <div class="banner-content text-center">
                    <h4 class="text-uppercase"><?= $description; ?></h4>
                    <h1><?= $title; ?></h1>
                   
                        <div class="primary-btn d-inline-flex align-items-center"><span class="mr-10">Selamat Datang <?= $user['name']; ?></span></div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<div class="main-wrapper">
    <div class="white-bg">
        <div class="container profil">
            <div class="row justify-content-center p-5">


            </div>
        </div>
    </div>