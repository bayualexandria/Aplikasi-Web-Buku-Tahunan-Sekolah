<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="<?= base_url('assets/web/img/azhar.png'); ?>">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title><?= $title; ?></title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
	<!--
		CSS
		============================================= -->
	<link rel="stylesheet" href="<?= base_url('assets/web/css/linearicons.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/web/css/owl.carousel.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/web/css/font-awesome.min.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/web/css/nice-select.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/web/css/magnific-popup.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/bootstrap-4/css/bootstrap.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/web/css/main.css'); ?>">
	<style>
		hr {
			border: 2px solid #3224b0;
			width: 3rem;
			margin-bottom: 2rem;
			border-radius: 12%;
			
		}

		.judul {
			font-weight: 700;
			font-size: 3rem;
			text-shadow: 0 0 1px 1px rgba(50, 50, 50, 0.3);
		}
		.namalogo{
			font-weight: 600;
			text-shadow: 0 0 5px 5px rgba(255, 255, 255, 0.3);
		}
		.teks{
			font-size:15px;
		}
	</style>
</head>

<body>
	<div class="main-wrapper-first">
		<div class="hero-area relative">
			<header>
				<div class="container">
					<div class="header-wrap">
						<div class="header-top d-flex justify-content-between align-items-center">
							<div class="logo text-center">
								<a href="<?= base_url('Website'); ?>"><img src="<?= base_url('assets/web/img/azhar.png'); ?>" alt="" style="widht:163px;height:50px;"></a>
								<h4 class="text-white">Azharku Media</h4>
							</div>
							<div class="main-menubar d-flex align-items-center">
								<nav class="hide">
									<a href="<?= base_url('Website'); ?>">Home</a>
									<a href="<?= base_url('Website/generic'); ?>">Portfolio</a>
									<a href="<?= base_url('Website/element'); ?>">Daftar Desain</a>
									<?php if ($user) : ?>
										<a href="<?= base_url('Pemesanan'); ?>">Pemesanan</a>
										<a href="<?= base_url('Profile/index/'); ?><?= $user['id']; ?>">Profile</a>
										<a href="<?= base_url('Auth/logout'); ?>" class="genric-btn primary-border circle arrow small text-capitalize">Logout</a>
									<?php elseif ($this->session->userdata('reset_email')) : ?>
									<?php else : ?>
										<a href="<?= base_url('Auth'); ?>" class="genric-btn primary-border circle arrow small text-capitalize">Login</a>
									<?php endif; ?>
								</nav>
								<?php if ($user == TRUE) : ?>
									<div class="pr-2">
										<a href="" class="dropdown">
											<img src="<?= base_url('assets/images/profile/') . $user['images']; ?>" class="img-thumbnail" style="border-radius:50%;width:55px;" alt="<?= $user['name']; ?>" data-toggle="tooltip" tabindex="0" title="<?= $user['name']; ?>">
										</a>
									</div>
								<?php endif; ?>
								<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
							</div>
						</div>
					</div>
				</div>
			</header>