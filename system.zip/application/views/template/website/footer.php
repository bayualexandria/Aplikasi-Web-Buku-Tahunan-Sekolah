<!-- End service Area -->
<!-- Start Contact Area -->
<section class="contact-area pt-100 pb-100 relative">
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row justify-content-center text-center">
			<div class="single-contact col-lg-6 col-md-8">
				<h2 class="text-white">Send Us <span>Message</span></h2>
				<p class="text-white">
					Most people who work in an office environment, buy computer products.
				</p>
			</div>
		</div>
		<form action="<?= base_url('Website/pesan'); ?>" method="post" class="contact-form">
			<div class="row justify-content-center">
				<?php if ($user == TRUE) : ?>
					<input type="hidden" name="email" value="<?= $user['email_pelanggan']; ?>">
					<div class="col-lg-10">
						<input name="name" placeholder="Enter your name" value="<?= $user['name']; ?>" class="common-input mt-20" type="text" readonly>
					</div>
				<?php else : ?>
					<div class="col-lg-5">
						<input name="name" placeholder="Enter your name" class="common-input mt-20" required type="text">
					</div>
					<div class="col-lg-5">
						<input name="email" placeholder="Enter email address" class="common-input mt-20" required type="email">
					</div>
				<?php endif; ?>
				<div class="col-lg-10">
					<textarea class="common-textarea mt-20" name="mess" placeholder="Messege" required></textarea>
				</div>
				<div class="col-lg-10 d-flex justify-content-end">
					<button type="submit" class="primary-btn white-bg d-inline-flex align-items-center mt-20"><span class="text-black mr-10">Send Message</span><span class="text-black lnr lnr-arrow-right"></span></button> <br>
				</div>
			</div>
		</form>
	</div>
</section>
<footer class="footer-area relative">
	<div class="container">
		<div class="footer-content d-flex flex-column align-items-center">
			<div class="footer-social">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>

			</div>
			<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
			<div class="copy-right-text">Copyright &copy;<?= Date('Y'); ?> All rights reserved | This Company of Azharku-Media</div>
			<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
		</div>
	</div>
</footer>
<!-- End footer Area -->
</div>





<script src="<?= base_url('assets/web/js/vendor/jquery-2.2.4.min.js'); ?>"></script>
<script src="<?= base_url('asssets/bootstrap-4/js/jquery-3.3.1.js') ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="<?= base_url('assets/bootstrap-4/js/bootstrap.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.ajaxchimp.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/owl.carousel.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.nice-select.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/parallax.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/jquery.magnific-popup.min.js'); ?>"></script>
<script src="<?= base_url('assets/web/js/main.js'); ?>"></script>

</body>

</html>