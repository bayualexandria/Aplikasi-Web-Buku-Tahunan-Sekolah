<?php 

function message()
{
    $kirim=get_instance();
    
}