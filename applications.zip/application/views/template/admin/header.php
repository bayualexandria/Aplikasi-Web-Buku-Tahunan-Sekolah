<!DOCTYPE html>
<html lang="en">

<head>
  <title><?= $title; ?></title>
<!-- <link rel="stylesheet" href="<?= base_url('assets/bootstrap-4/css/bootstrap.min.css');?>"> -->
  <link rel="stylesheet" href="<?= base_url('assets/admin/vendors/ti-icons/css/themify-icons.css'); ?>">
  <link rel="stylesheet" href="<?= base_url('assets/admin/vendors/base/vendor.bundle.base.css'); ?>">

  <link rel="stylesheet" href="<?= base_url('assets/admin/css/style.css'); ?>">

  <link rel="shortcut icon" href="<?= base_url('assets/web/img/azhar.png');?>" />
  <style>
    .pesan:hover{
      background-color: silver;
    }
  </style>
</head>

<body>
  <div class="container-scroller">