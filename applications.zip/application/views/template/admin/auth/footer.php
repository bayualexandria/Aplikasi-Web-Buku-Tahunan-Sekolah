<script src="<?= base_url('assets/admin/vendors/base/vendor.bundle.base.js'); ?>"></script>
<script src="<?= base_url('assets/bootstrap-4/js/jquery-3.3.1.js'); ?>"></script>
<!-- endinject -->
<!-- inject:js -->
<script src="<?= base_url('assets/admin/js/off-canvas.js'); ?>"></script>
<script src="<?= base_url('assets/admin/js/hoverable-collapse.js'); ?>"></script>
<script src="<?= base_url('assets/admin/js/template.js'); ?>"></script>
<script src="<?= base_url('assets/admin/js/todolist.js'); ?>"></script>
<script src="<?= base_url('assets/Library/SweetAlert/dist/sweetalert2.all.min.js'); ?>"></script>
<script src="<?= base_url('assets/Library/SweetAlert/dist/successlogin.js'); ?>"></script>
<!-- endinject -->
</body>

</html>
