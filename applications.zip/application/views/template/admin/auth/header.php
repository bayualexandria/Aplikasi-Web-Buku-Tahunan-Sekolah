<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= $title;?></title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?= base_url('assets/admin/vendors/ti-icons/css/themify-icons.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/admin/vendors/base/vendor.bundle.base.css'); ?>">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?= base_url('assets/admin/css/style.css'); ?>">
    <!-- endinject -->
    <link rel="shortcut icon" href="<?= base_url('assets/web/img/azhar.png');?>" />
</head>

<body>
<!-- <div class="salah" data-flashdata="<?= $this->session->flashdata('message_error'); ?>"></div> -->