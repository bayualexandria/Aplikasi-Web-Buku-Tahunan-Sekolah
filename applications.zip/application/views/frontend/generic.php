<div class="intro-page">
	<div class="container">
		
	</div>
</div>

<div class="wrapper">
	<section class="recent-works">
		<div class="container">
			<h2><?= $title;?></h2>
			<p><?= $description;?></p>
			<span class="dot-dash dark">.</span>
			<div class="recent-works--nav">
				<ul>
					<li class="active" data-filter="*">All Items</li>
					<li data-filter=".large">Katalog Besar</li>
					<li data-filter=".small">Katalog Kecil</li>
				</ul>
			</div>
		</div>
		<div class="recent-works--items">
			
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (5).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (5).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (6).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (6).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (7).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (7).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (8).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (8).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (9).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (9).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (10).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (10).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (11).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (11).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (12).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (12).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (13).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (13).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (14).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (14).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (15).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (15).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (16).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (16).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (17).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (17).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (18).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (18).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (19).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (19).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (20).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (20).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (21).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (21).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (22).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (22).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (23).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (23).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (24).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (24).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (25).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (25).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (26).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (26).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item small">
				<a href="<?= base_url();?>assets/images/website/desain (27).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (27).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
			<div class="recent-works--items__item large">
				<a href="<?= base_url();?>assets/images/website/desain (28).jpg">
					<img src="<?= base_url();?>assets/images/website/desain (28).jpg" alt="">
					<div class="inner-item">
						<div>
							<h4>T-Shirt Design</h4>
							<p>art / t-shirt</p>
						</div>
					</div>
				</a>
			</div>
		</div>
	</section>

	<section class="partners">
		<!-- <div class="container">
			<h2>Great Integrations with Others</h2>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
			<span class="dot-dash dark">.</span>
			<div class="partners--container">
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
				<div class="partners--item">
					<div class="partners--item__image">
						<img src="<?= base_url();?>assets/web/assets/img/partner1.png" alt="">
					</div>
				</div>
			</div>
		</div> -->
	</section>